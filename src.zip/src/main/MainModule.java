package main;

import dao.InsuranceServiceImpl;
import entity.Policy;
import java.util.Scanner;

public class MainModule {
    public static void main(String[] args) {
        InsuranceServiceImpl service = new InsuranceServiceImpl();
        Scanner scanner = new Scanner(System.in);
        boolean exit = false;

        System.out.println("Welcome to Insurance Management System!");

        while (!exit) {
            try {
                System.out.println("\n1. Create Policy");
                System.out.println("2. Get Policy");
                System.out.println("3. Update Policy");
                System.out.println("4. Delete Policy");
                System.out.println("5. Exit");
                System.out.print("Enter your choice: ");

                // Validate input type
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume the newline character

                switch (choice) {
                    case 1 -> createPolicy(service, scanner);
                    case 2 -> getPolicy(service, scanner);
                    case 3 -> updatePolicy(service, scanner);
                    case 4 -> deletePolicy(service, scanner);
                    case 5 -> {
                        System.out.println("Exiting... Goodbye!");
                        exit = true;
                    }
                    default -> System.out.println("Invalid choice. Please enter a valid option.");
                }
            } catch (java.util.InputMismatchException e) {
                System.out.println("Invalid input! Please enter a number.");
                scanner.nextLine(); // Clear the invalid input
            }
        }
        scanner.close();
    }

    private static void createPolicy(InsuranceServiceImpl service, Scanner scanner) {
        System.out.print("Enter Policy ID: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        System.out.print("Enter Policy Name: ");
        String name = scanner.nextLine();

        System.out.print("Enter Coverage Amount: ");
        double coverage = scanner.nextDouble();

        System.out.print("Enter Premium: ");
        double premium = scanner.nextDouble();

        Policy policy = new Policy(id, name, coverage, premium);
        if (service.createPolicy(policy)) {
            System.out.println("Policy created successfully!");
        } else {
            System.out.println("Failed to create policy.");
        }
    }

    private static void getPolicy(InsuranceServiceImpl service, Scanner scanner) {
        System.out.print("Enter Policy ID: ");
        int id = scanner.nextInt();
        Policy policy = service.getPolicy(id);
        if (policy != null) {
            System.out.println("Policy Found: " + policy);
        } else {
            System.out.println("Policy not found.");
        }
    }

    private static void updatePolicy(InsuranceServiceImpl service, Scanner scanner) {
        System.out.print("Enter Policy ID to update: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume the newline

        System.out.print("Enter New Policy Name: ");
        String name = scanner.nextLine();

        System.out.print("Enter New Coverage Amount: ");
        double coverage = scanner.nextDouble();

        System.out.print("Enter New Premium: ");
        double premium = scanner.nextDouble();

        Policy updatedPolicy = new Policy(id, name, coverage, premium);
        if (service.updatePolicy(updatedPolicy)) {
            System.out.println("Policy updated successfully!");
        } else {
            System.out.println("Failed to update policy.");
        }
    }

    private static void deletePolicy(InsuranceServiceImpl service, Scanner scanner) {
        System.out.print("Enter Policy ID to delete: ");
        int id = scanner.nextInt();
        if (service.deletePolicy(id)) {
            System.out.println("Policy deleted successfully!");
        } else {
            System.out.println("Policy not found.");
        }
    }
}

