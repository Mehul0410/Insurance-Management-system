package entity;

public class Client {
    private int clientId;
    private String clientName, contactInfo;
    private Policy policy;

    public Client() {}
    public Client(int clientId, String clientName, String contactInfo, Policy policy) {
        this.clientId = clientId; this.clientName = clientName;
        this.contactInfo = contactInfo; this.policy = policy;
    }
    public int getClientId() { return clientId; }
    public Policy getPolicy() { return policy; }
    public void setPolicy(Policy policy) { this.policy = policy; }
    public String toString() { return "Client{" + "clientId=" + clientId + ", clientName='" + clientName + "'}"; }
}