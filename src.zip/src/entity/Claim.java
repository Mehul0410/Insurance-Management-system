package entity;

import java.util.Date;

public class Claim {
    private int claimId;
    private String claimNumber, status;
    private double claimAmount;
    private Date dateFiled;
    private Policy policy;
    private Client client;

    public Claim() {}
    public Claim(int claimId, String claimNumber, double claimAmount, String status, Date dateFiled, Policy policy, Client client) {
        this.claimId = claimId; this.claimNumber = claimNumber; 
        this.claimAmount = claimAmount; this.status = status; 
        this.dateFiled = dateFiled; this.policy = policy; this.client = client;
    }
    public int getClaimId() { return claimId; }
    public String toString() { return "Claim{" + "claimId=" + claimId + ", status='" + status + "'}"; }
}