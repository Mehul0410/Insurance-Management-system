package entity;

public class Policy {
    private int policyId;
    private String policyName;
    private double coverageAmount, premium;

    public Policy() {}
    public Policy(int policyId, String policyName, double coverageAmount, double premium) {
        this.policyId = policyId; this.policyName = policyName;
        this.coverageAmount = coverageAmount; this.premium = premium;
    }
    public int getPolicyId() { return policyId; }
    public String toString() { return "Policy{" + "policyId=" + policyId + ", policyName='" + policyName + "'}"; }
}