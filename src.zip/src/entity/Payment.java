package entity;

import java.util.Date;

public class Payment {
    private int paymentId;
    private Date paymentDate;
    private double paymentAmount;
    private Client client;

    public Payment() {}
    public Payment(int paymentId, Date paymentDate, double paymentAmount, Client client) {
        this.paymentId = paymentId; this.paymentDate = paymentDate;
        this.paymentAmount = paymentAmount; this.client = client;
    }
    public int getPaymentId() { return paymentId; }
    public String toString() { return "Payment{" + "paymentId=" + paymentId + ", paymentAmount=" + paymentAmount + "}"; }
}