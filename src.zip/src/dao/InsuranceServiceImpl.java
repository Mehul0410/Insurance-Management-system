package dao;

import entity.Policy;
import java.util.ArrayList;
import java.util.Collection;

public class InsuranceServiceImpl implements IPolicyService {

    private final Collection<Policy> policies = new ArrayList<>();

    @Override
    public boolean createPolicy(Policy policy) {
        return policies.add(policy);
    }

    @Override
    public Policy getPolicy(int policyId) {
        return policies.stream()
                .filter(policy -> policy.getPolicyId() == policyId)
                .findFirst()
                .orElse(null);
    }

    @Override
    public Collection<Policy> getAllPolicies() {
        return new ArrayList<>(policies);
    }

    @Override
    public boolean updatePolicy(Policy updatedPolicy) {
        Policy existingPolicy = getPolicy(updatedPolicy.getPolicyId());
        if (existingPolicy != null) {
            policies.remove(existingPolicy);
            policies.add(updatedPolicy);
            return true;
        }
        return false;
    }

    @Override
    public boolean deletePolicy(int policyId) {
        Policy policy = getPolicy(policyId);
        return policies.remove(policy);
    }
}
