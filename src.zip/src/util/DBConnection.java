package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    private static Connection connection;

    public static Connection getConnection(String fileName) throws Exception {
        if (connection == null) {
            String connString = DBPropertyUtil.getPropertyString(fileName);
            connection = DriverManager.getConnection(connString);
        }
        return connection;
    }
}
